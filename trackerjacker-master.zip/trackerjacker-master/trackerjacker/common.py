# pylint: disable=C0111
MACS_TO_IGNORE = {'ff:ff:ff:ff:ff:ff', '00:00:00:00:00:00'}


class TJException(Exception):
    pass
